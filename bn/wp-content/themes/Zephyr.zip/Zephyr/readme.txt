=== Zephyr ===
Contributors: UpSolution team
Tags: animation, blog, business, clean, contact form, corporate, customizable, flexible, material design, modern, multipurpose, portfolio, responsive, retina, seo
Requires at least: 4.0
Tested up to: 4.2
Stable tag: 4.2
License: Themeforest Split Licence
License URI: -
Tags: animation, blog, business, clean, contact form, corporate, customizable, flexible, material design, modern, multipurpose, portfolio, responsive, retina, seo

== Description ==
The latest design trend with attention to details.

== Installation ==
1. In your admin panel, go to Appearance -> Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's ZIP file. Click Install Now.
3. Click Activate to use your new theme right away.