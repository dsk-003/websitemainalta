<?php defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

/**
 * Theme's migrations
 *
 * Note: do not change this file. Use separate filters for each theme instead.
 *
 * @filter us_config_migrations
 */

return array();
